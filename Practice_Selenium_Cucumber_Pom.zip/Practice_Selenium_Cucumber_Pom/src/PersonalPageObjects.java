import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import com.google.common.util.concurrent.Service.State;

public class PersonalPageObjects {

	public static void openPage(WebDriver driver) {
		driver.get("file:///C:/SeleniumWorkSpace/Practice_Selenium_Cucumber_Pom/WebContent/Personal.html?empNumber=543&name=f&state=Uttar+Pradesh&city=");
	}

	public static WebElement clickOnButton(WebDriver driver) {
		return driver.findElement(By.xpath("/html/body/form/button"));
	}

	public static Alert getAlert(WebDriver driver) {
		return driver.switchTo().alert();
	}

	public static WebElement enterEmployeeNumber(WebDriver driver) {
		return driver.findElement(By.xpath("//*[@id=\"empNumber\"]"));
	}

	public static WebElement enterEmployeeName(WebDriver driver) {
		return driver.findElement(By.xpath("//*[@id=\"name\"]"));
	}

	public static Select setState(WebDriver driver) {
		return new Select(driver.findElement(By.xpath("//*[@id=\"state\"]")));
		
	}

	public static Select setCity(WebDriver driver) {
		return new Select(driver.findElement(By.xpath("//*[@id=\"city\"]")));
	}
}
