package com.cg.test.project;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class PersonalPageObjects {

	public static void openPage(WebDriver driver) {
		driver.get("file:///C:/SeleniumWorkSpace/Practice_Selenium_Cucumber_Pom/WebContent/Project.html");
	}

	public static WebElement setProjectName(WebDriver driver) {
		return driver.findElement(By.xpath("//*[@id=\"name\"]"));
	}

	public static WebElement setPlatform(WebDriver driver) {
		return driver.findElement(By.xpath("//*[@id=\"platform1\"]"));
	}

	public static WebElement clickOnButton(WebDriver driver) {
		return driver.findElement(By.xpath("/html/body/form/button"));
	}
	
	

}
