package com.cg.test.project;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class ProjectSteps {
	
	private static WebDriver driver;
	
	@Given("^that I have gone to Project\\.jsp page$")
	public void that_I_have_gone_to_Project_jsp_page() throws Throwable {
		driver = new ChromeDriver();
		System.setProperty("webdriver.chrome.driver", "C:\\chromedriver.exe");
		driver.manage().deleteAllCookies();
		driver.manage().window().maximize();
		PersonalPageObjects.openPage(driver);
	}

	@When("^I entered the Project Name \"(.*?)\"$")
	public void i_entered_the_Project_Name(String arg1) throws Throwable {
		PersonalPageObjects.setProjectName(driver).sendKeys(arg1);;
	}

	@When("^I selected the platform \"(.*?)\"$")
	public void i_selected_the_platform(String arg1) throws Throwable {
		PersonalPageObjects.setPlatform(driver).click();
	}

	@When("^I clicked on the registration button$")
	public void i_clicked_on_the_registration_button() throws Throwable {
		PersonalPageObjects.clickOnButton(driver).click();
	}

	@Then("^It will registered the Employee$")
	public void it_will_registered_the_Employee() throws Throwable {
	
	}

}
