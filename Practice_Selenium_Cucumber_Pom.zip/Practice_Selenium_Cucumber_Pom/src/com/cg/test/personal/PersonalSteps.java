package com.cg.test.personal;
import static org.junit.Assert.assertEquals;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class PersonalSteps {

	private static WebDriver driver;

	@Given("^a Customer open the page$")
	public void a_Customer_open_the_page() throws Throwable {
		driver = new ChromeDriver();
		System.setProperty("webdriver.chrome.driver", "C:\\chromedriver.exe");
		driver.manage().deleteAllCookies();
		driver.manage().window().maximize();
		PersonalPageObjects.openPage(driver);
	}

	@When("^the Employee entered no details$")
	public void the_Employee_entered_no_details() throws Throwable {
		PersonalPageObjects.clickOnButton(driver).click();
	}

	@Then("^It should show a alert saying that \"(.*?)\"$")
	public void it_should_show_a_alert_saying_that(String arg1) throws Throwable {
		assertEquals(PersonalPageObjects.getAlert(driver).getText(), arg1);
		Thread.sleep(4000);
	    PersonalPageObjects.getAlert(driver).accept();
	    Thread.sleep(2000);
	}

	@When("^the Employee entered only Employee Number as \"(.*?)\"$")
	public void the_Employee_entered_only_Employee_Number_as(String arg1) throws Throwable {
		PersonalPageObjects.enterEmployeeNumber(driver).sendKeys(arg1);
	    PersonalPageObjects.clickOnButton(driver).click();
	}

	@When("^the Employee entered on Employee Number as \"(.*?)\" and name as \"(.*?)\"$")
	public void the_Employee_entered_on_Employee_Number_as_and_name_as(String arg1, String arg2) throws Throwable {
		PersonalPageObjects.enterEmployeeNumber(driver).sendKeys(arg1);
		PersonalPageObjects.enterEmployeeName(driver).sendKeys(arg2);
		PersonalPageObjects.clickOnButton(driver).click();
	}

	@When("^the Employee entered on Employee Number as \"(.*?)\", name as \"(.*?)\", state as \"(.*?)\"$")
	public void the_Employee_entered_on_Employee_Number_as_name_as_state_as(String arg1, String arg2, String arg3) throws Throwable {
		PersonalPageObjects.enterEmployeeNumber(driver).sendKeys(arg1);
		PersonalPageObjects.enterEmployeeName(driver).sendKeys(arg2);
		Select state = PersonalPageObjects.setState(driver);
		state.selectByVisibleText(arg3);
		PersonalPageObjects.clickOnButton(driver).click();
	}

	@When("^the Employees entered on Employee Number as \"(.*?)\", name as \"(.*?)\", state as \"(.*?)\", city as \"(.*?)\"$")
	public void the_Employee_entered_on_Employee_Number_as_name_as_state_as_city_as(String arg1, String arg2, String arg3, String arg4) throws Throwable {
		PersonalPageObjects.enterEmployeeNumber(driver).sendKeys(arg1);
		PersonalPageObjects.enterEmployeeName(driver).sendKeys(arg2);
		Select state = PersonalPageObjects.setState(driver);
		state.selectByVisibleText(arg3);
		Select city = PersonalPageObjects.setCity(driver);
		city.selectByVisibleText(arg4);
		PersonalPageObjects.clickOnButton(driver).click();
	}


}
